# game_of_life
I made conway's life game with pygame.
- Execution method

```sh
$ python3 main.py
```

- Operation

When you want to start game, press space key.
When you want to end the game, just press enter key
If you want to change the state of a cell, press the space key during execution and then click the cell you want to specify. 
I use google translate. I am japanese student.
Sorry bad english.